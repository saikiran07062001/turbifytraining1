package com.infinite.loginandregister;

import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.sql.DataSource;
import org.springframework.stereotype.Controller;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
public class LoginController {
	/**
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public String login(HttpServletRequest request, HttpServletResponse response) {
		Connection con = null;
		String fullname = request.getParameter("fullname");// getting data from web
		String password = request.getParameter("password");// getting data from web
		try {
			DataSource datasource = HikariCPTest.getDataSource();
			con = datasource.getConnection();
			PreparedStatement ps = con.prepareStatement("select fullname,password from register where fullname=?");
			ps.setString(1, fullname);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString(1).equals(fullname)) { // validating fullname
					if (rs.getString(2).equals(password)) {// validating password
						return "welcome";
					} else {
						return "invalid";
					}
				} else {
					return "invalid";
				}
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (Exception e1) {
			System.out.println(e1);
		}
		return "invalid";
	}
}
